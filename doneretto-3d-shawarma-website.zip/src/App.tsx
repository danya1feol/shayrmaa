import { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowRight, ArrowUpRight, Check, Coffee, Copy, MapPin, Menu as MenuIcon, Minus, Plus, ShoppingBag, X } from 'lucide-react';
import './index.css';
import { shawarmaCutout, menuClassic, menuBig as menuSpicy, menuCheese, coffeeImg, logoGenerated } from './assets/images';

/*
  Логотип Донеретто (вместо ✳ в шапке, бегущей строке, декоре и подвале).
  Сейчас используется логотип из src/assets/images.ts (logoGenerated).
  Чтобы подставить оригинальный файл, положите его в src/assets/logo.png
  (или .webp / .jpg / .svg) либо в public/images/logo.png — он автоматически
  заменит логотип ниже, больше ничего менять не нужно.
*/
const logoFiles = {
  ...import.meta.glob('./assets/logo.{png,webp,jpg,jpeg,svg}', { eager: true, import: 'default' }),
  ...import.meta.glob('../public/images/logo.{png,webp,jpg,jpeg,svg}', { eager: true, import: 'default' }),
} as Record<string, string>;
const logoSrc: string = Object.values(logoFiles)[0] ?? logoGenerated;

function LogoGlyph() {
  return <img className="logo-img" src={logoSrc} alt="" width={256} height={256} decoding="async" draggable={false} />;
}

type Product = {
  id: string;
  name: string;
  title?: string;
  description?: string;
  price: number;
  size?: string;
  image?: string;
  tag?: string;
};

/* ───────── Меню: шаурма (карточки с фото) ───────── */
const featured: Product[] = [
  { id: 'classic', name: 'Шаурма классическая', title: 'Классическая', description: 'Тот самый вкус: сочная начинка, свежие овощи и хрустящий лаваш.', price: 240, image: menuClassic, tag: 'ХИТ' },
  { id: 'big', name: 'Шаурма большая', title: 'Большая', description: 'Для настоящего аппетита: больше начинки и больше удовольствия.', price: 270, image: menuSpicy, tag: 'ПОБОЛЬШЕ' },
  { id: 'cheese', name: 'Шаурма с сыром', title: 'С сыром', description: 'Любимая классика с тягучим сыром и фирменным соусом.', price: 270, image: menuCheese, tag: 'С СЫРОМ' },
];

/* ───────── Меню: остальное ───────── */
const more: Product[] = [
  { id: 'doner-chicken', name: 'Донер с курицей', description: 'Нежная курица, свежие овощи и соус', price: 270 },
  { id: 'doner-sausage', name: 'Донер с сосиской', description: 'Сытный вариант с сосиской, овощами и соусом', price: 220 },
  { id: 'lula', name: 'Люля в лаваше', description: 'Сочный люля-кебаб в тёплом лаваше', price: 350 },
  { id: 'veg', name: 'Шаурма вегетарианская', description: 'Свежие овощи и соус, без мяса', price: 180 },
  { id: 'sausage', name: 'Сосиска в лаваше', description: 'Быстрый и сытный перекус в тёплом лаваше', price: 220 },
];

/* ───────── Меню: напитки (200 мл / 350 мл) ───────── */
type Drink = { id: string; name: string; small: number; large?: number };

const drinks: Drink[] = [
  { id: 'espresso', name: 'Эспрессо', small: 70 },
  { id: 'americano', name: 'Американо', small: 90 },
  { id: 'cappuccino', name: 'Капучино', small: 90, large: 160 },
  { id: 'vanilla-cappuccino', name: 'Ванильный капучино', small: 90, large: 160 },
  { id: 'latte', name: 'Латте', small: 90, large: 160 },
  { id: 'coffee-milk', name: 'Кофе с молоком', small: 90 },
  { id: 'hot-chocolate', name: 'Горячий шоколад', small: 90 },
  { id: 'milk-chocolate', name: 'Молочный шоколад', small: 90 },
  { id: 'mochaccino', name: 'Мокачино', small: 90 },
  { id: 'tea', name: 'Чай', small: 50 },
  { id: 'lemon-tea', name: 'Чай с лимоном', small: 60 },
];

const drinkRows = drinks.map((drink) => {
  const small: Product = { id: `${drink.id}-200`, name: drink.name, price: drink.small, size: drink.large ? '200 мл' : undefined };
  const large: Product | undefined = drink.large ? { id: `${drink.id}-350`, name: drink.name, price: drink.large, size: '350 мл' } : undefined;
  return { name: drink.name, small, large };
});

const drinkProducts: Product[] = drinkRows.flatMap((row) => (row.large ? [row.small, row.large] : [row.small]));
const allProducts: Product[] = [...featured, ...more, ...drinkProducts];
const mapsUrl = 'https://yandex.ru/maps/org/doneretto/12068675545?si=87uux2922kw647txyr1ab0kp3g';

function formatPrice(price: number) {
  return `${price} ₽`;
}

function fullName(product: Product) {
  return product.size ? `${product.name} ${product.size}` : product.name;
}

function RotatingShawarma() {
  const [dragging, setDragging] = useState(false);
  const [rotation, setRotation] = useState(0);
  const start = useRef({ x: 0, rotation: 0 });

  return (
    <div
      className={`shawarma-stage ${dragging ? 'is-dragging' : ''}`}
      onPointerDown={(event) => {
        setDragging(true);
        start.current = { x: event.clientX, rotation };
        event.currentTarget.setPointerCapture(event.pointerId);
      }}
      onPointerMove={(event) => {
        if (dragging) setRotation(start.current.rotation + (event.clientX - start.current.x) * 0.5);
      }}
      onPointerUp={() => { setDragging(false); setRotation(0); }}
      onPointerCancel={() => { setDragging(false); setRotation(0); }}
      role="img"
      aria-label="Вращающаяся 3D-шаурма. Потяните, чтобы покрутить"
    >
      <div className="shawarma-aura" />
      <div className="shawarma-spinner" style={dragging ? { animation: 'none', transform: `rotateY(${rotation}deg) rotateZ(-7deg)` } : undefined}>
        <div className="shawarma-face shawarma-front"><img src={shawarmaCutout} alt="" draggable="false" /></div>
        <div className="shawarma-face shawarma-back"><img src={shawarmaCutout} alt="" draggable="false" /></div>
      </div>
      <div className="shawarma-shadow" />
    </div>
  );
}

function Reveal({ children, className = '' }: { children: React.ReactNode; className?: string }) {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) {
        element.classList.add('is-visible');
        observer.unobserve(element);
      }
    }, { threshold: 0.12 });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  return <div ref={ref} className={`reveal ${className}`}>{children}</div>;
}

function PricePill({ product, count, onAdd }: { product: Product; count: number; onAdd: (product: Product) => void }) {
  return (
    <button
      className={`price-pill ${count ? 'is-active' : ''}`}
      onClick={() => onAdd(product)}
      aria-label={`Добавить ${fullName(product)} за ${formatPrice(product.price)}${count ? `, уже в заказе: ${count}` : ''}`}
    >
      <span>{formatPrice(product.price)}</span>
      {count ? <b>{count}</b> : <Plus size={14} strokeWidth={2.5} />}
    </button>
  );
}

export default function App() {
  const [cart, setCart] = useState<Record<string, number>>({});
  const [cartOpen, setCartOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState('');
  const totalCount = Object.values(cart).reduce((sum, count) => sum + count, 0);
  const totalPrice = allProducts.reduce((sum, product) => sum + product.price * (cart[product.id] || 0), 0);

  useEffect(() => {
    document.body.style.overflow = cartOpen ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [cartOpen]);

  useEffect(() => {
    if (!toast) return;
    const timeout = window.setTimeout(() => setToast(''), 2400);
    return () => window.clearTimeout(timeout);
  }, [toast]);

  function addItem(product: Product) {
    setCart((current) => ({ ...current, [product.id]: (current[product.id] || 0) + 1 }));
    setToast(`${fullName(product)} в заказе`);
  }

  function changeQuantity(id: string, delta: number) {
    setCart((current) => {
      const next = { ...current };
      next[id] = Math.max(0, (next[id] || 0) + delta);
      if (!next[id]) delete next[id];
      return next;
    });
  }

  async function copyOrder() {
    const lines = allProducts.filter((product) => cart[product.id]).map((product) => `${fullName(product)} × ${cart[product.id]} — ${formatPrice(product.price * cart[product.id])}`);
    const text = `Заказ в Донеретто:\n${lines.join('\n')}\nИтого: ${formatPrice(totalPrice)}\nАдрес: ул. Дзержинского, 4А`;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2500);
    } catch {
      setToast('Не удалось скопировать заказ');
    }
  }

  const navLinks = [
    { label: 'Шаурма', href: '#menu' },
    { label: 'Ещё', href: '#more' },
    { label: 'Напитки', href: '#coffee' },
    { label: 'Где мы', href: '#location' },
  ];

  return (
    <div className="site-shell">
      <header className="site-header">
        <a className="logo" href="#top" aria-label="Донеретто, на главную"><span className="logo-mark" aria-hidden="true"><LogoGlyph /></span><span>донеретто<span className="logo-dot">.</span></span></a>
        <nav className="desktop-nav" aria-label="Основная навигация">
          {navLinks.map((link) => <a key={link.href} href={link.href}>{link.label}</a>)}
        </nav>
        <button className="header-order" onClick={() => setCartOpen(true)} aria-label={`Открыть заказ, товаров: ${totalCount}`}>
          <ShoppingBag size={17} strokeWidth={2.3} /><span>Мой заказ</span>{totalCount > 0 && <b>{totalCount}</b>}
        </button>
        <button className="mobile-menu-button" onClick={() => setMobileOpen(!mobileOpen)} aria-label={mobileOpen ? 'Закрыть меню' : 'Открыть меню'}>{mobileOpen ? <X /> : <MenuIcon />}</button>
      </header>

      {mobileOpen && <nav className="mobile-nav" aria-label="Мобильная навигация">{navLinks.map((link) => <a key={link.href} href={link.href} onClick={() => setMobileOpen(false)}>{link.label}<ArrowUpRight size={20} /></a>)}<button onClick={() => { setMobileOpen(false); setCartOpen(true); }}>Мой заказ <ShoppingBag size={20} /></button></nav>}

      <main>
        <section className="hero" id="top">
          <div className="hero-noise" />
          <div className="hero-ring" />
          <div className="hero-content">
            <div className="hero-kicker"><span className="kicker-line" /> ШАУРМА С ХАРАКТЕРОМ</div>
            <h1>ДОНЕ<br />РЕТТО<span>.</span></h1>
            <p className="hero-subtitle">Завернём твой день во что-то вкусное.</p>
            <a href="#menu" className="button button-coral">Смотреть меню <ArrowUpRight size={21} strokeWidth={2.3} /></a>
          </div>
          <RotatingShawarma />
          <div className="hero-bottom"><span>СОЧНО В КАЖДОМ КУСОЧКЕ</span><a href="#menu" aria-label="Листать к меню">ЛИСТАЙ ВНИЗ <ArrowDown size={16} /></a></div>
        </section>

        <div className="marquee" aria-hidden="true"><div className="marquee-track">{Array.from({ length: 4 }).map((_, index) => <span key={index}>СОЧНО <i><LogoGlyph /></i> ВКУСНО <i><LogoGlyph /></i> ПО-НАСТОЯЩЕМУ <i><LogoGlyph /></i> </span>)}</div></div>

        {/* 01 — Шаурма */}
        <section className="menu-section section-pad" id="menu">
          <div className="section-inner">
            <Reveal className="section-heading menu-heading">
              <div><span className="eyebrow">01 / ГЛАВНЫЕ ГЕРОИ</span><h2>Вот ради чего<br /><em>всё завертелось.</em></h2></div>
              <p>Хрустящий лаваш, сочная начинка и соус, который хочется добавить ещё. Выбирай свою.</p>
            </Reveal>
            <div className="product-grid">
              {featured.map((product, index) => (
                <Reveal className="product" key={product.id}>
                  <div className={`product-image product-image-${index + 1}`}>
                    <img src={product.image} alt={product.name} loading="lazy" />
                    <span className="product-tag">{product.tag}</span>
                  </div>
                  <div className="product-topline"><h3>{product.title ?? product.name}</h3><span>{formatPrice(product.price)}</span></div>
                  <p>{product.description}</p>
                  <button className="product-add" onClick={() => addItem(product)}>
                    {cart[product.id] ? `В заказе: ${cart[product.id]} · добавить ещё` : 'Добавить в заказ'}
                    <span><Plus size={18} strokeWidth={2.2} /></span>
                  </button>
                </Reveal>
              ))}
            </div>
          </div>
        </section>

        {/* 02 — Донер, люля и остальное */}
        <section className="extras-section section-pad" id="more">
          <div className="section-inner extras-layout">
            <Reveal className="extras-intro">
              <span className="eyebrow">02 / НЕ ТОЛЬКО ШАУРМА</span>
              <h2>Донер, люля<br /><em>и компания.</em></h2>
              <p>На любой аппетит и любое настроение. Выбирай, что хочется прямо сейчас.</p>
              <div className="extras-scribble" aria-hidden="true"><LogoGlyph /></div>
            </Reveal>
            <Reveal className="extras-list">
              {more.map((product) => (
                <div className="line-item" key={product.id}>
                  <div><h3>{product.name}</h3><p>{product.description}</p></div>
                  <span className="line-price">{formatPrice(product.price)}</span>
                  <button className={cart[product.id] ? 'is-active' : ''} onClick={() => addItem(product)} aria-label={`Добавить ${product.name}`}>
                    {cart[product.id] ? cart[product.id] : <Plus size={22} />}
                  </button>
                </div>
              ))}
            </Reveal>
          </div>
        </section>

        {/* 03 — Кофе и напитки */}
        <section className="coffee-section section-pad" id="coffee">
          <div className="section-inner coffee-layout">
            <Reveal className="coffee-visual">
              <img src={coffeeImg} alt="Кофе в стаканчиках Донеретто" loading="lazy" />
              <span className="coffee-stamp" aria-hidden="true"><Coffee size={33} strokeWidth={1.6} /><span>КОФЕ &<br />ХОРОШИЙ ДЕНЬ</span></span>
            </Reveal>
            <Reveal className="coffee-content">
              <span className="eyebrow">03 / КОФЕ И НАПИТКИ</span>
              <h2>Пауза<br /><em>со вкусом.</em></h2>
              <p className="coffee-lead">Горячий кофе, шоколад и чай — к сочной шаурме или просто так, потому что хочется.</p>
              <div className="drink-table">
                <div className="drink-head"><span /><span>200 мл</span><span>350 мл</span></div>
                {drinkRows.map((row) => (
                  <div className="drink-row" key={row.small.id}>
                    <h3>{row.name}</h3>
                    <PricePill product={row.small} count={cart[row.small.id] || 0} onAdd={addItem} />
                    {row.large ? <PricePill product={row.large} count={cart[row.large.id] || 0} onAdd={addItem} /> : <span className="drink-empty" />}
                  </div>
                ))}
              </div>
              <p className="drink-hint">Нажмите на цену, чтобы добавить напиток в заказ.</p>
            </Reveal>
          </div>
        </section>

        <section className="location-section section-pad" id="location"><div className="section-inner location-layout"><Reveal><span className="eyebrow">04 / ВСТРЕТИМСЯ?</span><h2>Ждём тебя<br /><em>на вкусное.</em></h2><p>Забегай за любимой шаурмой и кофе. Мы уже тут.</p></Reveal><Reveal className="location-address"><MapPin size={33} strokeWidth={1.6} /><span>НАШ АДРЕС</span><strong>ул. Дзержинского,<br />4А</strong><a href={mapsUrl} target="_blank" rel="noreferrer" className="button button-light">Построить маршрут <ArrowUpRight size={21} /></a></Reveal></div><span className="location-watermark" aria-hidden="true">ДОНЕРЕТТО</span></section>
      </main>

      <footer className="footer"><a className="logo footer-logo" href="#top" aria-label="Донеретто, наверх"><span className="logo-mark" aria-hidden="true"><LogoGlyph /></span><span>донеретто<span className="logo-dot">.</span></span></a><span>Вкусно быть собой.</span><a href={mapsUrl} target="_blank" rel="noreferrer">ул. Дзержинского, 4А <ArrowUpRight size={16} /></a><a href="#top" className="back-top">Наверх ↑</a></footer>

      {toast && <div className="toast" role="status"><Check size={16} />{toast}</div>}

      {cartOpen && (
        <div className="drawer-wrap">
          <div className="drawer-backdrop" onClick={() => setCartOpen(false)} />
          <aside className="cart-drawer" role="dialog" aria-modal="true" aria-label="Мой заказ">
            <div className="drawer-head">
              <div><span className="eyebrow">ДОНЕРЕТТО</span><h2>Мой заказ<span>.</span></h2></div>
              <button onClick={() => setCartOpen(false)} aria-label="Закрыть заказ"><X size={25} /></button>
            </div>
            {totalCount === 0 ? (
              <div className="empty-cart">
                <ShoppingBag size={54} strokeWidth={1.2} />
                <h3>Пока пусто</h3>
                <p>Самое время выбрать что-нибудь вкусное.</p>
                <button className="button button-coral" onClick={() => setCartOpen(false)}>Посмотреть меню <ArrowRight size={19} /></button>
              </div>
            ) : (
              <>
                <div className="cart-items">
                  {allProducts.filter((product) => cart[product.id]).map((product) => (
                    <div className="cart-item" key={product.id}>
                      <div><h3>{fullName(product)}</h3><span>{formatPrice(product.price)} / шт.</span></div>
                      <div className="cart-item-right">
                        <strong>{formatPrice(product.price * cart[product.id])}</strong>
                        <div className="quantity">
                          <button onClick={() => changeQuantity(product.id, -1)} aria-label={`Убрать ${fullName(product)}`}><Minus size={15} /></button>
                          <span>{cart[product.id]}</span>
                          <button onClick={() => changeQuantity(product.id, 1)} aria-label={`Добавить ${fullName(product)}`}><Plus size={15} /></button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="cart-bottom">
                  <div className="cart-total"><span>Итого</span><strong>{formatPrice(totalPrice)}</strong></div>
                  <button className="button button-coral copy-button" onClick={copyOrder}>{copied ? 'Заказ скопирован' : 'Скопировать заказ'} {copied ? <Check size={19} /> : <Copy size={19} />}</button>
                  <p>Скопируй список и покажи его нам при заказе на месте.</p>
                </div>
              </>
            )}
          </aside>
        </div>
      )}
    </div>
  );
}
